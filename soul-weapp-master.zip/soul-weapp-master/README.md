# soul-weapp 简介
小程序常用商城组件案例及营销组件
<p>
  <img src="https://tweapp.top1buyer.com/preview/index.png" width="300"  style="display:inline;">
</p>
# 运行例子
git clone https://github.com/sunnie1992/soul-weapp.git

微信开发者工具打开项目
# 更新日志
2019.03.04 更新 小程序保存多张图片到相册
#  营销组件
<p>
大转盘  "pages/wheel/index"   
</p>
<p>
  <img src="https://tweapp.top1buyer.com/page1.gif" width="400"  style="display:inline;">
</p>
<p>
九宫格翻牌  "pages/gridCard/index"
</p>
<p>
  <img src="https://tweapp.top1buyer.com/page2.gif" width="400"  style="display:inline;">
</p>
<p>
红包雨     "pages/packetRain/index"
</p>
<p>
  <img src="https://tweapp.top1buyer.com/page6.gif" width="400"  style="display:inline;">
</p>

# 页面
"pages/filter/index"      功能筛选

# 筛选预览
<p>
  <img src="https://tweapp.top1buyer.com/page5.gif" width="600"  style="display:inline;">
</p>

# 关于我

您可以扫描添加下方的微信并备注 Soul 加交流群，给我提意见，交流学习。
<p>
  <img src="https://tweapp.top1buyer.com/mine.jpg" width="256" style="display:inline;">
</p>
 
如果对你有帮助送我一颗小星星（づ￣3￣）づ╭❤～

