# flop-xcx
微信小程序翻牌抽奖效果
#

appid 已经被删除，使用的时候替换自己的appid
