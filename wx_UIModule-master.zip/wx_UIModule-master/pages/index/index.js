Page({
  data: {
    dataSource: [{ 'name': '底部弹出视图-Dialog', 'path': '/pages/view/Dialog' }, { 'name': '支付密码输入框-PassWordInput', 'path': '/pages/view/pwdInput' }, { 'name': '商品数量加减-Quantity', 'path': '/pages/view/numberPlusMinus' }, { 'name': '提示消息-Toast', 'path': '/pages/view/messageView' }, { 'name': '顶部提示-Toptip', 'path': '/pages/view/topMessage' }, { 'name': '角标-Badge', 'path': '/pages/view/badge' }, { 'name': '星级评分-Rater', 'path': '/pages/view/star' }, { 'name': '图表-Chart', 'path': '/pages/view/chart' }, { 'name': '富文本解析-RichText', 'path': '/pages/view/rich_text' }, { 'name': '图片截取-Screen', 'path': '/pages/view/screen' }]
  },
  onLoad: function (options) {
    
  },
  onReady: function () {
    
  },
  onShow: function () {
    
  },
  onHide: function () {
    
  },
  onUnload: function () {
    
  },
  onPullDownRefresh: function () {
    
  },
  onReachBottom: function () {
    
  },
  onShareAppMessage: function () {
    
  }
})